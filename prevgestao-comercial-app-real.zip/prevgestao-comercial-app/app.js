
(function(){
const STORAGE_KEY = "prevgestao_comercial_state_v2";

function deepClone(v){ return JSON.parse(JSON.stringify(v)); }
function slug(v){ return (v||"").toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,""); }
function fmtDate(v){ if(!v) return "—"; const d = new Date(v+"T00:00:00"); if(Number.isNaN(d.getTime())) return v; return d.toLocaleDateString("pt-BR"); }
function monthLabel(v){ if(!v) return "Sem data"; const [y,m]=v.split("-"); return new Date(Number(y), Number(m)-1, 1).toLocaleDateString("pt-BR",{month:"short", year:"2-digit"}); }
function todayISO(){ return new Date().toISOString().slice(0,10); }
function uid(prefix="id"){ return prefix + "-" + Math.random().toString(36).slice(2,10); }
function textIncludes(haystack, needles){
  const txt = (haystack || "").toString().toLowerCase();
  return needles.some(n => txt.includes(n));
}
function getInitials(name){
  return (name || "PG").split(/\s+/).filter(Boolean).slice(0,2).map(x => x[0]?.toUpperCase()).join("");
}
function saveState(state){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function loadState(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(raw){
    try { return JSON.parse(raw); } catch(e){}
  }
  const seed = deepClone(window.PREV_SEED);
  seed.session = { userId: null };
  return seed;
}
let state = loadState();

function applyTheme(){
  document.body.className = state.settings.theme === "light" ? "light" : "";
  if(state.settings.layout === "compact") document.body.classList.add("compact");
  document.documentElement.style.setProperty("--primary", state.settings.primaryColor);
  document.documentElement.style.setProperty("--accent", state.settings.accentColor);
}
applyTheme();

function currentUser(){
  return state.users.find(u => u.id === state.session.userId) || null;
}

function smartPresetButtons(context="modal"){
  const presets = state.templates.smartPresets || [];
  if(!presets.length) return "";
  const limit = context === "modal" ? 8 : 6;
  return `<div class="smart-preset-list">${
    presets.slice(0, limit).map((p, idx) => `
      <button type="button" class="smart-preset" data-smart-preset='${JSON.stringify(p).replace(/'/g,"&#39;")}'>
        <strong>${p.label}</strong>
        <span>${p.attendant || "sem atendimento"} • ${p.contractType} • ${p.sector}</span>
      </button>`).join("")
  }</div>`;
}

function login(loginName, password){
  const user = state.users.find(u => u.login === loginName && u.password === password && u.active !== false);
  if(!user) return false;
  state.session.userId = user.id;
  saveState(state);
  return true;
}
function logout(){
  state.session.userId = null;
  saveState(state);
  render();
}

function computeMetrics(contracts){
  const now = new Date();
  const monthPrefix = now.toISOString().slice(0,7);
  const filtered = contracts;
  const total = filtered.length;
  const thisMonth = filtered.filter(c => (c.caseDate || "").startsWith(monthPrefix)).length;
  const pending = filtered.filter(c => c.stage === "PENDENCIA DOCUMENTAL").length;
  const ready = filtered.filter(c => c.stage === "PRONTO PARA SETOR").length;
  const byBenefit = {};
  const byOrigin = {};
  const byAttendant = {};
  const monthly = {};
  filtered.forEach(c => {
    byBenefit[c.benefitType || "OUTROS"] = (byBenefit[c.benefitType || "OUTROS"] || 0) + 1;
    byOrigin[c.origin || "N/I"] = (byOrigin[c.origin || "N/I"] || 0) + 1;
    const att = (c.attendant || "N/I").split(/[\/,;-]/).map(x => x.trim()).filter(Boolean)[0] || "N/I";
    byAttendant[att] = (byAttendant[att] || 0) + 1;
    const m = (c.caseDate || "sem-data").slice(0,7);
    monthly[m] = (monthly[m] || 0) + 1;
  });
  const topPending = filtered
    .filter(c => c.stage === "PENDENCIA DOCUMENTAL")
    .slice(0,8);
  return { total, thisMonth, pending, ready, users: state.users.filter(u => u.active !== false).length, byBenefit, byOrigin, byAttendant, monthly, topPending };
}

function makeBarList(obj, maxItems = 8, formatter = v => v){
  const items = Object.entries(obj).sort((a,b)=>b[1]-a[1]).slice(0,maxItems);
  const max = items[0]?.[1] || 1;
  return `<div class="bar-list">${
    items.map(([label,val]) => `
      <div class="bar-row">
        <div>${label}</div>
        <div class="bar"><span style="width:${(val/max)*100}%"></span></div>
        <div>${formatter(val)}</div>
      </div>`).join("")
  }</div>`;
}

function renderLogin(){
  const app = document.getElementById("app");
  app.innerHTML = `
    <div class="login-shell">
      <div class="login-card">
        <div class="hero-pane">
          <div class="brand">
            <div class="brand-badge">PG</div>
            <div>
              <strong>${state.settings.companyName || "PrevGestão Comercial"}</strong>
              <div class="muted small">Sistema comercial pronto para uso</div>
            </div>
          </div>
          <h1>Controle comercial com histórico real, relatórios e configuração total.</h1>
          <p>Esta versão já entra com a sua base histórica carregada, painel por benefício, produtividade por atendimento, filtros, usuários, configurações visuais e cadastro rápido de novos contratos.</p>
          <div class="hero-bullets">
            <div><strong>Operação inteligente</strong><br><span class="muted">Cadastro rápido, filtros, relatórios e atalhos para o preenchimento de novos contratos.</span></div>
            <div><strong>Governança</strong><br><span class="muted">Gestão de usuários, permissões simples, personalização de marca, tema claro/escuro e backup local.</span></div>
            <div><strong>Base pronta</strong><br><span class="muted">${state.meta.seedRecordCount.toLocaleString("pt-BR")} registros históricos já carregados.</span></div>
          </div>
        </div>
        <div class="form-pane">
          <h2>Entrar</h2>
          <p class="muted">Usuário padrão: <strong>admin</strong> | Senha: <strong>admin123</strong></p>
          <form id="loginForm" class="form-grid">
            <label class="field"><span>Login</span><input name="login" value="admin" required /></label>
            <label class="field"><span>Senha</span><input type="password" name="password" value="admin123" required /></label>
            <button class="btn" type="submit">Acessar o sistema</button>
          </form>
        </div>
      </div>
    </div>
  `;
  document.getElementById("loginForm").addEventListener("submit", e => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    if(login(form.get("login"), form.get("password"))){ render(); }
    else { alert("Login inválido."); }
  });
}

const navItems = [
  ["dashboard","Dashboard"],
  ["contracts","Contratos"],
  ["reports","Relatórios"],
  ["users","Usuários"],
  ["settings","Configurações"],
];

let ui = { page: "dashboard", query:"", filters:{month:"", benefit:"", origin:"", attendant:"", stage:""} };

function filterContracts(){
  return state.contracts.filter(c => {
    if(ui.query){
      const q = ui.query.toLowerCase();
      const blob = [c.clientName,c.origin,c.attendant,c.benefitType,c.notes,c.sourceSheet].join(" ").toLowerCase();
      if(!blob.includes(q)) return false;
    }
    if(ui.filters.month && (c.caseDate || "").slice(0,7) !== ui.filters.month) return false;
    if(ui.filters.benefit && c.benefitType !== ui.filters.benefit) return false;
    if(ui.filters.origin && (c.origin || "N/I") !== ui.filters.origin) return false;
    if(ui.filters.attendant && !(c.attendant || "").includes(ui.filters.attendant)) return false;
    if(ui.filters.stage && c.stage !== ui.filters.stage) return false;
    return true;
  });
}

function pageDashboard(){
  const contracts = filterContracts();
  const m = computeMetrics(contracts);
  const monthly = Object.entries(m.monthly).filter(([k]) => k !== "sem-data").sort((a,b)=>a[0].localeCompare(b[0])).slice(-10)
    .reduce((acc,[k,v]) => (acc[monthLabel(k)] = v, acc), {});
  return `
    <div class="grid">
      <div class="kpi-grid grid">
        ${[
          ["Base total", m.total],
          ["Entradas do mês atual", m.thisMonth],
          ["Pendências documentais", m.pending],
          ["Prontos para setor", m.ready],
        ].map(([label,val]) => `<div class="card kpi-card"><div class="value">${Number(val).toLocaleString("pt-BR")}</div><div class="label">${label}</div></div>`).join("")}
      </div>

      <div class="split">
        <div class="card">
          <h3>Produção por mês</h3>
          ${makeBarList(monthly, 10, v => v.toLocaleString("pt-BR"))}
        </div>
        <div class="card">
          <h3>Distribuição por benefício</h3>
          ${makeBarList(m.byBenefit, 8, v => v.toLocaleString("pt-BR"))}
        </div>
      </div>

      <div class="split">
        <div class="card">
          <h3>Origens mais frequentes</h3>
          ${makeBarList(m.byOrigin, 8, v => v.toLocaleString("pt-BR"))}
        </div>
        <div class="card">
          <h3>Atendimento mais ativo</h3>
          ${makeBarList(m.byAttendant, 8, v => v.toLocaleString("pt-BR"))}
        </div>
      </div>

      <div class="card">
        <div class="flex" style="justify-content:space-between">
          <h3>Pendências prioritárias</h3>
          <span class="muted small">Critério: anotações com falta, sem laudo, atualizar ou pendente</span>
        </div>
        ${m.topPending.length ? `
          <div class="table-wrap">
            <table>
              <thead><tr><th>Cliente</th><th>Data</th><th>Benefício</th><th>Atendimento</th><th>Observação</th></tr></thead>
              <tbody>
                ${m.topPending.map(c => `
                  <tr>
                    <td>${c.clientName}</td>
                    <td>${fmtDate(c.caseDate)}</td>
                    <td>${c.benefitType}</td>
                    <td>${c.attendant || "—"}</td>
                    <td>${c.notes || "—"}</td>
                  </tr>`).join("")}
              </tbody>
            </table>
          </div>` : `<div class="empty">Nenhuma pendência encontrada para os filtros atuais.</div>`}
      </div>
    </div>
  `;
}

function contractTag(stage){
  const map = {
    "CONCLUIDO":"success",
    "PENDENCIA DOCUMENTAL":"danger",
    "PRONTO PARA SETOR":"warning",
    "EM ANDAMENTO":""
  };
  return `<span class="tag ${map[stage] || ""}">${stage}</span>`;
}

function contractForm(record = null){
  const edit = !!record;
  const r = record || {
    id: uid("contract"),
    sourceSheet: "MANUAL",
    clientName: "",
    origin: "",
    caseDate: todayISO(),
    attendant: "",
    recoveredBy: "",
    benefitRaw: "",
    benefitType: "BPC/LOAS",
    contractType: "PRESENCIAL",
    sector: "ADM",
    advBox: "",
    drive: "",
    notes: "",
    points: "",
    stage: "EM ANDAMENTO",
  };
  return `
    <div class="modal-backdrop open" id="contractModal">
      <div class="modal">
        <div class="modal-header">
          <div>
            <h2 style="margin:0">${edit ? "Editar contrato" : "Novo contrato"}</h2>
            <div class="muted">Atalhos inteligentes alimentados com os padrões do seu histórico.</div>
          </div>
          <button class="btn ghost" data-close-modal>Fechar</button>
        </div>
        <div class="grid">
          <div class="card">
            <h3>Botões rápidos</h3>
            <div class="grid">
              <div>
                <div class="muted small">Combinações prontas do histórico real</div>
                ${smartPresetButtons("modal")}
              </div>
              <div>
                <div class="muted small">Benefícios</div>
                <div class="quick-buttons">${
                  state.templates.benefits.map(v => `<button type="button" data-preset="benefitType" data-value="${v}">${v}</button>`).join("")
                }</div>
              </div>
              <div>
                <div class="muted small">Origens mais usadas</div>
                <div class="quick-buttons">${
                  state.templates.origins.slice(0,10).map(v => `<button type="button" data-preset="origin" data-value="${v}">${v}</button>`).join("")
                }</div>
              </div>
              <div>
                <div class="muted small">Atendimento</div>
                <div class="quick-buttons">${
                  state.templates.attendants.map(v => `<button type="button" data-preset="attendant" data-value="${v}">${v}</button>`).join("")
                }</div>
              </div>
            </div>
          </div>

          <form id="contractForm" class="form-cols">
            <input type="hidden" name="id" value="${r.id}">
            <label class="field full"><span>Nome do cliente</span><input name="clientName" value="${escapeHtml(r.clientName)}" required></label>
            <label class="field"><span>Data do contrato</span><input type="date" name="caseDate" value="${r.caseDate || todayISO()}"></label>
            <label class="field"><span>Origem</span><input name="origin" value="${escapeHtml(r.origin)}"></label>
            <label class="field"><span>Atendimento</span><input name="attendant" value="${escapeHtml(r.attendant)}"></label>
            <label class="field"><span>Recuperado por</span><input name="recoveredBy" value="${escapeHtml(r.recoveredBy)}"></label>
            <label class="field"><span>Benefício</span>
              <select name="benefitType">${state.templates.benefits.map(v => `<option ${v===r.benefitType?"selected":""}>${v}</option>`).join("")}</select>
            </label>
            <label class="field"><span>Tipo de contrato</span>
              <select name="contractType">${["PRESENCIAL","ONLINE"].map(v => `<option ${v===r.contractType?"selected":""}>${v}</option>`).join("")}</select>
            </label>
            <label class="field"><span>Setor</span>
              <select name="sector">${["ADM","JUDICIAL","ONLINE","—"].map(v => `<option ${v===r.sector?"selected":""}>${v}</option>`).join("")}</select>
            </label>
            <label class="field"><span>Status operacional</span>
              <select name="stage">${state.templates.stages.map(v => `<option ${v===r.stage?"selected":""}>${v}</option>`).join("")}</select>
            </label>
            <label class="field"><span>ADV Box / Chat</span><input name="advBox" value="${escapeHtml(r.advBox)}"></label>
            <label class="field"><span>Drive</span><input name="drive" value="${escapeHtml(r.drive)}"></label>
            <label class="field"><span>Pontos</span><input name="points" value="${escapeHtml(r.points)}"></label>
            <label class="field full"><span>Observações</span><textarea name="notes">${escapeHtml(r.notes)}</textarea></label>
            <div class="full flex" style="justify-content:flex-end">
              <button class="btn secondary" type="button" data-close-modal>Cancelar</button>
              <button class="btn" type="submit">${edit ? "Salvar alterações" : "Cadastrar contrato"}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
}

function openContractModal(record = null){
  document.body.insertAdjacentHTML("beforeend", contractForm(record));
  const modal = document.getElementById("contractModal");
  modal.querySelectorAll("[data-close-modal]").forEach(btn => btn.addEventListener("click", ()=> modal.remove()));
  modal.querySelectorAll("[data-preset]").forEach(btn => btn.addEventListener("click", e => {
    const {preset, value} = e.currentTarget.dataset;
    const field = modal.querySelector(`[name="${preset}"]`);
    if(field) field.value = value;
  }));
  modal.querySelector("#contractForm").addEventListener("submit", e => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    payload.sourceSheet = record?.sourceSheet || "MANUAL";
    const idx = state.contracts.findIndex(c => c.id === payload.id);
    if(idx >= 0) state.contracts[idx] = { ...state.contracts[idx], ...payload };
    else state.contracts.unshift(payload);
    saveState(state);
    modal.remove();
    render();
  });
}

function pageContracts(){
  const contracts = filterContracts();
  const months = [...new Set(state.contracts.map(c => (c.caseDate || "").slice(0,7)).filter(Boolean))].sort().reverse();
  const benefits = [...new Set(state.contracts.map(c => c.benefitType).filter(Boolean))].sort();
  const origins = [...new Set(state.contracts.map(c => c.origin || "N/I"))].sort();
  const attendants = [...new Set(state.contracts.flatMap(c => (c.attendant || "").split(/[\/,;-]/).map(x => x.trim()).filter(Boolean)))].sort();

  return `
    <div class="grid">
      <div class="card">
        <div class="toolbar">
          <input id="searchContracts" placeholder="Buscar cliente, observação, origem..." value="${escapeHtml(ui.query)}" />
          <select id="filterMonth"><option value="">Todos os meses</option>${months.map(v => `<option value="${v}" ${ui.filters.month===v?"selected":""}>${monthLabel(v)}</option>`).join("")}</select>
          <select id="filterBenefit"><option value="">Todos os benefícios</option>${benefits.map(v => `<option ${ui.filters.benefit===v?"selected":""}>${v}</option>`).join("")}</select>
          <select id="filterOrigin"><option value="">Todas as origens</option>${origins.map(v => `<option ${ui.filters.origin===v?"selected":""}>${v}</option>`).join("")}</select>
          <select id="filterAttendant"><option value="">Todo atendimento</option>${attendants.map(v => `<option ${ui.filters.attendant===v?"selected":""}>${v}</option>`).join("")}</select>
          <select id="filterStage"><option value="">Todos os status</option>${state.templates.stages.map(v => `<option ${ui.filters.stage===v?"selected":""}>${v}</option>`).join("")}</select>
          <button class="btn" id="newContractBtn">Novo contrato</button>
          <button class="btn secondary" id="exportCsvBtn">Exportar CSV</button>
        </div>
        <div class="muted small">Resultado atual: <strong>${contracts.length.toLocaleString("pt-BR")}</strong> contratos</div>
      </div>

      <div class="card">
        <h3>Cadastro acelerado</h3>
        <div class="grid">
          <div>
            <div class="muted small">Modelos inteligentes com base no histórico real</div>
            ${smartPresetButtons("page")}
          </div>
          <div class="settings-grid">
            <div>
              <div class="muted small">Benefícios mais frequentes</div>
              <div class="quick-buttons">${state.templates.benefits.slice(0,6).map(v => `<button type="button" class="quick-create" data-template='${JSON.stringify({ benefitType:v }).replace(/'/g,"&#39;")}'>${v}</button>`).join("")}</div>
            </div>
            <div>
              <div class="muted small">Origens mais frequentes</div>
              <div class="quick-buttons">${state.templates.origins.slice(0,8).map(v => `<button type="button" class="quick-create" data-template='${JSON.stringify({ origin:v }).replace(/'/g,"&#39;")}'>${v}</button>`).join("")}</div>
            </div>
          </div>
        </div>
      </div>

      <div class="card table-wrap">
        <table>
          <thead><tr>
            <th>Cliente</th><th>Data</th><th>Origem</th><th>Benefício</th><th>Atendimento</th><th>Contrato</th><th>Setor</th><th>Status</th><th>Obs.</th><th></th>
          </tr></thead>
          <tbody>
            ${contracts.slice(0,350).map(c => `
              <tr>
                <td><strong>${c.clientName}</strong><div class="muted small">${c.sourceSheet}</div></td>
                <td>${fmtDate(c.caseDate)}</td>
                <td>${c.origin || "—"}</td>
                <td>${c.benefitType || "—"}</td>
                <td>${c.attendant || "—"}</td>
                <td>${c.contractType || "—"}</td>
                <td>${c.sector || "—"}</td>
                <td>${contractTag(c.stage || "EM ANDAMENTO")}</td>
                <td>${c.notes || "—"}</td>
                <td><button class="btn secondary edit-contract" data-id="${c.id}">Editar</button></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
        ${contracts.length > 350 ? `<div class="muted small" style="padding-top:12px">Mostrando os primeiros 350 registros do filtro atual para manter a navegação leve.</div>` : ""}
      </div>
    </div>
  `;
}

function pageReports(){
  const contracts = filterContracts();
  const m = computeMetrics(contracts);
  const topMonths = Object.entries(m.monthly).filter(([k])=>k!=="sem-data").sort((a,b)=>b[0].localeCompare(a[0])).slice(0,12);
  const conversionBase = m.total || 1;
  return `
    <div class="grid">
      <div class="report-grid">
        <div class="card"><h3>Total da base filtrada</h3><div class="value" style="font-size:34px;font-weight:800">${m.total.toLocaleString("pt-BR")}</div></div>
        <div class="card"><h3>% com pendência</h3><div class="value" style="font-size:34px;font-weight:800">${((m.pending/conversionBase)*100).toFixed(1).replace(".",",")}%</div></div>
        <div class="card"><h3>% prontos para setor</h3><div class="value" style="font-size:34px;font-weight:800">${((m.ready/conversionBase)*100).toFixed(1).replace(".",",")}%</div></div>
      </div>

      <div class="split">
        <div class="card">
          <h3>Leitura gerencial</h3>
          <p class="muted">O sistema destaca onde a operação está concentrando esforços, quais benefícios puxam a carteira e onde há gargalo documental. A ideia aqui não é só registrar: é permitir decisão rápida do gestor.</p>
          <ul>
            <li>Maior volume: <strong>${Object.entries(m.byBenefit).sort((a,b)=>b[1]-a[1])[0]?.[0] || "—"}</strong></li>
            <li>Origem dominante: <strong>${Object.entries(m.byOrigin).sort((a,b)=>b[1]-a[1])[0]?.[0] || "—"}</strong></li>
            <li>Atendimento mais carregado: <strong>${Object.entries(m.byAttendant).sort((a,b)=>b[1]-a[1])[0]?.[0] || "—"}</strong></li>
          </ul>
        </div>
        <div class="card">
          <h3>Volume mensal</h3>
          ${makeBarList(Object.fromEntries(topMonths.reverse().map(([k,v])=>[monthLabel(k),v])), 12)}
        </div>
      </div>

      <div class="split">
        <div class="card">
          <h3>Benefícios</h3>
          ${makeBarList(m.byBenefit, 10)}
        </div>
        <div class="card">
          <h3>Origens</h3>
          ${makeBarList(m.byOrigin, 10)}
        </div>
      </div>
    </div>
  `;
}

function pageUsers(){
  return `
    <div class="grid">
      <div class="card">
        <div class="flex" style="justify-content:space-between">
          <div>
            <h3>Usuários do sistema</h3>
            <div class="muted">Edite login, senha, função e foto do perfil.</div>
          </div>
          <button class="btn" id="addUserBtn">Novo usuário</button>
        </div>
      </div>
      <div class="grid">
        ${state.users.map(user => `
          <div class="card">
            <div class="profile-card">
              <div class="avatar" style="${user.photo ? `background-image:url('${user.photo}')` : ''}">${!user.photo ? getInitials(user.name) : ""}</div>
              <div>
                <strong>${user.name}</strong>
                <div class="muted small">${user.role} · ${user.login}</div>
              </div>
            </div>
            <div class="toolbar" style="margin-top:14px">
              <button class="btn secondary edit-user" data-id="${user.id}">Editar</button>
              ${user.id !== "u-admin" ? `<button class="btn danger delete-user" data-id="${user.id}">Excluir</button>` : ""}
            </div>
          </div>`).join("")}
      </div>
    </div>
  `;
}

function userForm(user = null){
  const u = user || { id: uid("user"), name:"", role:"atendente", login:"", password:"123456", photo:"", email:"", active:true };
  return `
    <div class="modal-backdrop open" id="userModal">
      <div class="modal">
        <div class="modal-header">
          <h2 style="margin:0">${user ? "Editar usuário" : "Novo usuário"}</h2>
          <button class="btn ghost" data-close-modal>Fechar</button>
        </div>
        <form id="userForm" class="form-cols">
          <input type="hidden" name="id" value="${u.id}">
          <label class="field"><span>Nome</span><input name="name" value="${escapeHtml(u.name)}" required></label>
          <label class="field"><span>Função</span><select name="role">${["admin","supervisor","advogado","atendente"].map(r => `<option ${u.role===r?"selected":""}>${r}</option>`).join("")}</select></label>
          <label class="field"><span>Login</span><input name="login" value="${escapeHtml(u.login)}" required></label>
          <label class="field"><span>Senha</span><input name="password" value="${escapeHtml(u.password)}" required></label>
          <label class="field full"><span>Foto do perfil (URL)</span><input name="photo" value="${escapeHtml(u.photo)}"></label>
          <label class="field full"><span>E-mail</span><input name="email" value="${escapeHtml(u.email)}"></label>
          <div class="full flex" style="justify-content:flex-end">
            <button class="btn secondary" type="button" data-close-modal>Cancelar</button>
            <button class="btn" type="submit">Salvar usuário</button>
          </div>
        </form>
      </div>
    </div>`;
}
function openUserModal(user = null){
  document.body.insertAdjacentHTML("beforeend", userForm(user));
  const modal = document.getElementById("userModal");
  modal.querySelectorAll("[data-close-modal]").forEach(btn => btn.addEventListener("click", ()=>modal.remove()));
  modal.querySelector("#userForm").addEventListener("submit", e => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    const idx = state.users.findIndex(u => u.id === payload.id);
    if(idx >= 0) state.users[idx] = { ...state.users[idx], ...payload };
    else state.users.push(payload);
    saveState(state);
    modal.remove();
    render();
  });
}

function pageSettings(){
  return `
    <div class="grid">
      <div class="settings-grid">
        <div class="card">
          <h3>Identidade visual</h3>
          <div class="form-grid">
            <label class="field"><span>Nome da operação</span><input id="settingsCompany" value="${escapeHtml(state.settings.companyName)}"></label>
            <label class="field"><span>Logo / foto (URL)</span><input id="settingsLogo" value="${escapeHtml(state.settings.logoUrl || "")}"></label>
            <div class="flex">
              <label class="field" style="flex:1"><span>Cor principal</span><input type="color" id="settingsPrimary" value="${state.settings.primaryColor}"></label>
              <label class="field" style="flex:1"><span>Cor de apoio</span><input type="color" id="settingsAccent" value="${state.settings.accentColor}"></label>
            </div>
          </div>
        </div>

        <div class="card">
          <h3>Experiência do usuário</h3>
          <div class="form-grid">
            <label class="field"><span>Tema</span><select id="settingsTheme"><option value="dark" ${state.settings.theme==="dark"?"selected":""}>Escuro</option><option value="light" ${state.settings.theme==="light"?"selected":""}>Claro</option></select></label>
            <label class="field"><span>Densidade do layout</span><select id="settingsLayout"><option value="comfortable" ${state.settings.layout==="comfortable"?"selected":""}>Confortável</option><option value="compact" ${state.settings.layout==="compact"?"selected":""}>Compacto</option></select></label>
            <div class="flex">
              <button class="btn" id="saveSettingsBtn">Salvar configurações</button>
              <button class="btn secondary" id="resetSeedBtn">Restaurar base inicial</button>
            </div>
          </div>
        </div>

        <div class="card">
          <h3>Backup e portabilidade</h3>
          <div class="form-grid">
            <button class="btn secondary" id="exportBackupBtn">Exportar backup JSON</button>
            <label class="field"><span>Importar backup</span><input type="file" id="importBackupInput" accept=".json"></label>
            <div class="muted small">Esse sistema funciona em navegador e grava localmente. O backup preserva usuários, configurações e contratos.</div>
          </div>
        </div>

        <div class="card">
          <h3>Resumo da base importada</h3>
          <p><strong>${state.meta.seedRecordCount.toLocaleString("pt-BR")}</strong> registros reais carregados.</p>
          <p>Período: <strong>${fmtDate(state.meta.historicalRange.start)}</strong> até <strong>${fmtDate(state.meta.historicalRange.end)}</strong>.</p>
          <p class="muted small">A base operacional foi montada a partir do arquivo real de contratos enviado. Dados sensíveis da planilha de salário-maternidade, como CPF e senha, não entram na interface comercial.</p>
        </div>
      </div>
    </div>
  `;
}

function escapeHtml(str){
  return (str || "").toString()
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;");
}

function renderApp(){
  const user = currentUser();
  const app = document.getElementById("app");
  const pageTitleMap = {
    dashboard: ["Dashboard comercial","Visão executiva da base, gargalos e distribuição da carteira."],
    contracts: ["Contratos","Cadastro rápido, filtros, edição e exportação."],
    reports: ["Relatórios","Leitura gerencial para decidir com mais velocidade."],
    users: ["Usuários","Perfis, logins, foto e acessos."],
    settings: ["Configurações","Marca, cores, tema, layout e backup."],
  };
  const [title, subtitle] = pageTitleMap[ui.page];
  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand">
          <div class="brand-badge">${state.settings.logoUrl ? `<img src="${state.settings.logoUrl}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:14px">` : "PG"}</div>
          <div>
            <strong>${state.settings.companyName}</strong>
            <div class="muted small">${state.meta.seedRecordCount.toLocaleString("pt-BR")} registros</div>
          </div>
        </div>
        <div class="nav">
          ${navItems.map(([id,label]) => `<button class="${ui.page===id?"active":""}" data-nav="${id}"><span>${label}</span><span>›</span></button>`).join("")}
        </div>
        <div class="sidebar-footer">
          <div class="profile-card">
            <div class="avatar" style="${user?.photo ? `background-image:url('${user.photo}')` : ''}">${!user?.photo ? getInitials(user?.name) : ""}</div>
            <div>
              <strong>${user?.name || "Usuário"}</strong>
              <div class="muted small">${user?.role || ""}</div>
            </div>
          </div>
          <button class="btn ghost" id="logoutBtn">Sair</button>
        </div>
      </aside>
      <main class="main">
        <div class="topbar">
          <div class="page-title">
            <h1>${title}</h1>
            <p>${subtitle}</p>
          </div>
          <div class="top-actions">
            ${ui.page !== "contracts" ? `<button class="btn" id="quickNewBtn">Novo contrato</button>` : ""}
            <button class="btn secondary" id="goSettingsBtn">⚙️ Configurações</button>
          </div>
        </div>
        ${ui.page === "dashboard" ? pageDashboard() : ""}
        ${ui.page === "contracts" ? pageContracts() : ""}
        ${ui.page === "reports" ? pageReports() : ""}
        ${ui.page === "users" ? pageUsers() : ""}
        ${ui.page === "settings" ? pageSettings() : ""}
      </main>
    </div>
  `;
  bindEvents();
}

function exportCsv(rows){
  const columns = ["clientName","caseDate","origin","attendant","recoveredBy","benefitType","contractType","sector","stage","advBox","drive","notes","sourceSheet"];
  const csv = [columns.join(";")]
    .concat(rows.map(r => columns.map(k => `"${(r[k] || "").toString().replaceAll('"','""')}"`).join(";")))
    .join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "prevgestao-contratos.csv";
  a.click();
}

function exportJsonBackup(){
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "prevgestao-backup.json";
  a.click();
}

function bindEvents(){
  document.querySelectorAll("[data-nav]").forEach(btn => btn.addEventListener("click", () => { ui.page = btn.dataset.nav; render(); }));
  document.getElementById("logoutBtn")?.addEventListener("click", logout);
  document.getElementById("quickNewBtn")?.addEventListener("click", () => openContractModal());
  document.getElementById("goSettingsBtn")?.addEventListener("click", () => { ui.page = "settings"; render(); });

  document.getElementById("searchContracts")?.addEventListener("input", e => { ui.query = e.target.value; render(); });
  ["Month","Benefit","Origin","Attendant","Stage"].forEach(key => {
    const el = document.getElementById("filter" + key);
    if(el) el.addEventListener("change", e => { ui.filters[key.toLowerCase()] = e.target.value; render(); });
  });
  document.getElementById("newContractBtn")?.addEventListener("click", () => openContractModal());
  document.getElementById("exportCsvBtn")?.addEventListener("click", () => exportCsv(filterContracts()));
  document.querySelectorAll(".edit-contract").forEach(btn => btn.addEventListener("click", () => {
    const rec = state.contracts.find(c => c.id === btn.dataset.id);
    if(rec) openContractModal(rec);
  }));
  document.querySelectorAll(".quick-create").forEach(btn => btn.addEventListener("click", () => {
    const template = JSON.parse(btn.dataset.template);
    openContractModal({ ...template, id: uid("contract"), caseDate: todayISO(), clientName:"", contractType:"PRESENCIAL", sector:"ADM", stage:"EM ANDAMENTO" });
  }));
  document.querySelectorAll(".smart-preset").forEach(btn => btn.addEventListener("click", () => {
    const template = JSON.parse(btn.dataset.smartPreset);
    const payload = { ...template, id: uid("contract"), caseDate: todayISO(), clientName:"", stage:"EM ANDAMENTO" };
    delete payload.label;
    delete payload.count;
    openContractModal(payload);
  }));

  document.getElementById("addUserBtn")?.addEventListener("click", ()=> openUserModal());
  document.querySelectorAll(".edit-user").forEach(btn => btn.addEventListener("click", () => openUserModal(state.users.find(u => u.id === btn.dataset.id))));
  document.querySelectorAll(".delete-user").forEach(btn => btn.addEventListener("click", () => {
    if(confirm("Excluir este usuário?")){
      state.users = state.users.filter(u => u.id !== btn.dataset.id);
      saveState(state); render();
    }
  }));

  document.getElementById("saveSettingsBtn")?.addEventListener("click", () => {
    state.settings.companyName = document.getElementById("settingsCompany").value;
    state.settings.logoUrl = document.getElementById("settingsLogo").value;
    state.settings.primaryColor = document.getElementById("settingsPrimary").value;
    state.settings.accentColor = document.getElementById("settingsAccent").value;
    state.settings.theme = document.getElementById("settingsTheme").value;
    state.settings.layout = document.getElementById("settingsLayout").value;
    saveState(state); applyTheme(); render();
  });
  document.getElementById("resetSeedBtn")?.addEventListener("click", () => {
    if(confirm("Restaurar a base original carregada do seed? Isso substitui alterações locais.")){
      localStorage.removeItem(STORAGE_KEY);
      state = loadState();
      applyTheme();
      render();
    }
  });
  document.getElementById("exportBackupBtn")?.addEventListener("click", exportJsonBackup);
  document.getElementById("importBackupInput")?.addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if(!file) return;
    const text = await file.text();
    try {
      state = JSON.parse(text);
      saveState(state);
      applyTheme();
      render();
    } catch(err){
      alert("Backup inválido.");
    }
  });
}

function render(){
  applyTheme();
  if(!currentUser()) return renderLogin();
  return renderApp();
}
render();
})();
